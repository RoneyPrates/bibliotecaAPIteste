package com.example.bibliotecaapi.model;

public class Usuario {
    private Integer id;
    private String nome;
    private String cargo;
}
