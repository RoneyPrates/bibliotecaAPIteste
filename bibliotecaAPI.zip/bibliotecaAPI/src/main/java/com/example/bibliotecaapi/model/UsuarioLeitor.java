package com.example.bibliotecaapi.model;

public class UsuarioLeitor {
    private Integer id;
    private String nome;
    private Integer idade;
}
