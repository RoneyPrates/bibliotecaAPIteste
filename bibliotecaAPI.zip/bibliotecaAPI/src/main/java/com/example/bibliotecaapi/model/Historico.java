package com.example.bibliotecaapi.model;

import java.util.Date;

public class Historico {
    private Integer id;
    private String descricao;
    private Date data_alteração;
    private String observacao;
    private String prioridade;
    private String status;
    private Integer fk_Usuario;
    private Integer fk_Task;
}
