package com.example.bibliotecaapi.model;

import java.util.Date;

public class Task {

    private Integer id;
    private String descricao;
    private Date data_previsao;
    private String prioridade;
    private String status;
    private Date data_inicio;
    private Date data_termino;
    private Integer fk_Usuario;
}
