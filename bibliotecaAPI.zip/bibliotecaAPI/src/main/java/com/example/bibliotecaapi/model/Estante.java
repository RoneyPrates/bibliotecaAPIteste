package com.example.bibliotecaapi.model;

public class Estante {
    private Integer id;
    private String descricao;
    private String estou_lendo;
    private Integer fk_Usuario;
}
